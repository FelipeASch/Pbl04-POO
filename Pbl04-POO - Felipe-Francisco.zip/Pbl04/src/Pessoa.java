import java.util.ArrayList;
import java.util.Scanner;

public class Pessoa {
    protected String Nome;
    protected String Cpf;
    protected int idade, nivelAcesso;

    public Pessoa(String nome, String cpf, int idade) {
        Nome = nome;
        Cpf = cpf;
        this.idade = idade;
    }

    public String getNome() {
        return Nome;
    }
    public void setNome(String nome) {
        Nome = nome;
    }
    public String getCpf() {
        return Cpf;
    }
    public void setCpf(String cpf) {
        Cpf = cpf;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
    public int getNivelAcesso() {
        return nivelAcesso;
    }
    public void setNivelAcesso(int nivelAcesso) {
        this.nivelAcesso = nivelAcesso;
    }
}

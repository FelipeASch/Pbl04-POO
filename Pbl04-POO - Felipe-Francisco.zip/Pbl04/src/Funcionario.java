public class Funcionario extends Pessoa{
    public Funcionario(String nome, String cpf, int idade, int nivelAcesso) {
        super(nome, cpf, idade);
        this.nivelAcesso = nivelAcesso;
    }
    public void mostrarFuncionario(){
        System.out.println("Funcionário - Nome: "+getNome()+" Idade: "+getIdade()+" Cpf: "+getCpf()+
                " Nível de Acesso: "+getNivelAcesso());
    }
}

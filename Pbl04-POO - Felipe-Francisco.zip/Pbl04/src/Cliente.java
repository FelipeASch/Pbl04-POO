public class Cliente extends Pessoa {
    public Cliente(String nome, String cpf, int idade, int nivelAcesso) {
        super(nome, cpf, idade);
        this.nivelAcesso = nivelAcesso;
    }
    public void mostrarCliente(){
        System.out.println("Cliente - Nome: "+getNome()+" Idade: "+getIdade()+" Cpf: "+getCpf()+
                " Nível de Acesso: "+getNivelAcesso());
    }
}

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
    ArrayList<Cliente> Clientes = new ArrayList<>();
    ArrayList<Funcionario> Funcionarios = new ArrayList<>();
    ArrayList<Gerente> Gerentes = new ArrayList<>();
        Scanner scan1 = new Scanner(System.in);
        while(true){
            System.out.println("""
                [1] Cadastrar pessoa
                [2] Lista de pesssoas
                [3] Buscar pessoa por nível de acesso
                [4] Finalizar o programa""");
            int operacao = scan1.nextInt();
            if(operacao == 1){
                System.out.println("""
                        Para cadastrar uma pessoa você precisará das seguintes informações: 
                        Nome, Idade, Cpf e Nível de acesso ao sistema, sendo:
                        1 = Cliente | 2 = Funcionário | 3 = Gerente""");
                System.out.println("=================================================");
                System.out.println("Nome: ");
                String nome = scan1.next();
                System.out.println("Idade: ");
                int idade = scan1.nextInt();
                System.out.println("Cpf: ");
                String cpf = scan1.next();
                System.out.println("Nível de Acesso: ");
                int nivelAcesso = scan1.nextInt();

                if(nivelAcesso == 1){
                    Clientes.add(new Cliente(nome,cpf,idade,1));
                }
                if(nivelAcesso == 2){
                    Funcionarios.add(new Funcionario(nome,cpf,idade,2));
                }
                if(nivelAcesso == 3){
                    Gerentes.add(new Gerente(nome,cpf,idade,3));
                }
            }
            else if (operacao == 2){
                for (Cliente cliente : Clientes){
                    cliente.mostrarCliente();
                }
                for (Funcionario funcionario : Funcionarios){
                    funcionario.mostrarFuncionario();
                }
                for (Gerente gerente : Gerentes){
                    gerente.mostrarGerente();
                }
            }
            else if(operacao == 3){
                System.out.println("""
                        Selecione o nível de acesso em que a pessoa está
                        [1] Nível de Acesso: Cliente
                        [2] Nível de Acesso: Funcionário
                        [3] Nível de Acesso: Gerente""");
                int selecaoBusca = scan1.nextInt();
                if(selecaoBusca == 1){
                    for(Cliente cliente : Clientes){
                        cliente.mostrarCliente();
                    }
                }
                else if(selecaoBusca == 2){
                    for(Funcionario funcionario : Funcionarios){
                        funcionario.mostrarFuncionario();
                    }
                }
                else if(selecaoBusca == 3){
                    for(Gerente gerente : Gerentes){
                        gerente.mostrarGerente();
                    }
                }
            }
            else{
                System.out.println("Finalizando...");
                break;
            }
        }
    }
}

public class Gerente extends Pessoa{
    public Gerente(String nome, String cpf, int idade, int nivelAcesso) {
        super(nome, cpf, idade);
        this.nivelAcesso = nivelAcesso;
    }
    public void mostrarGerente(){
        System.out.println("Gerente - Nome: "+getNome()+" Idade: "+getIdade()+" Cpf: "+getCpf()+
                " Nível de Acesso: "+getNivelAcesso());
    }
}
